package com.baida.util;

import java.util.List;

import com.baida.domain.Address;
import com.baida.domain.Article;
import com.baida.domain.Product;

public class ListUtil {
	public static List<Product> products = null;
	public static List<Article> articles = null;
	public static List<Product> collects = null;
	public static List<Address> address = null;
	public static String elementkey = null;
	public static String articlekey = null;
}
