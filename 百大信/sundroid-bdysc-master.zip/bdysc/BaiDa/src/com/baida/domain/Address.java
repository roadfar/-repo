package com.baida.domain;

public class Address {
private String name;
private String address;
private String jiedao;
private String check;

public String getCheck() {
	return check;
}
public void setCheck(String check) {
	this.check = check;
}
public String getJiedao() {
	return jiedao;
}
public void setJiedao(String jiedao) {
	this.jiedao = jiedao;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
private String phone;
}
