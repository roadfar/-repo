package com.baida.domain;

public class Article {
private String url;
private String time;
private String name;
public String getUrl() {
	return url;
}
public void setUrl(String url) {
	this.url = url;
}
public String getTime() {
	return time;
}
public void setTime(String time) {
	this.time = time;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}

}
