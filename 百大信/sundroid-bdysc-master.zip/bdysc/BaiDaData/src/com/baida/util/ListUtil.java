package com.baida.util;

import java.util.List;

import com.baida.domain.Product;

public class ListUtil {
	public static List<Product> products = null;

}
